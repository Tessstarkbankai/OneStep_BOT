# OutrightBot UI — Step 16

This package contains a dependency-free, professional web dashboard for the OutrightBot FastAPI backend.

## Files

- `ui/index.html` — dashboard shell
- `ui/styles.css` — complete light SaaS design system
- `ui/app.js` — API integration and interactions
- `api/ui.py` — FastAPI routes serving the dashboard at `/dashboard`

No Node/npm build is required.

## Install into your existing project

Assuming OutrightBot is at:

```bash
/web/Ayushmaan/OutrightBOT
```

Copy the package contents:

```bash
cd /web/Ayushmaan/OutrightBOT

cp -r /PATH/TO/outrightbot_ui_step16/ui .
cp /PATH/TO/outrightbot_ui_step16/api/ui.py api/ui.py
```

In `app/main.py`, add:

```python
from api.ui import (
    router as ui_router,
)
```

Then add this with your other router registrations:

```python
app.include_router(
    ui_router
)
```

Compile:

```bash
python -m compileall \
app \
api \
ui
```

Start FastAPI:

```bash
uvicorn app.main:app \
--host 0.0.0.0 \
--port 8085 \
--reload
```

Open:

```text
http://YOUR_VM_IP:8085/dashboard
```

For local testing on the VM:

```text
http://127.0.0.1:8085/dashboard
```

## API endpoints used by the UI

The dashboard expects the backend created in Steps 1–15:

- `GET /api/workspaces`
- `GET /api/llm/health`
- `POST /api/workspaces/{workspace_id}/assistant/ask`
- `POST /api/workspaces/{workspace_id}/patches`
- `GET /api/workspaces/{workspace_id}/patches?limit=N`
- `GET /api/patches/{patch_id}`
- `POST /api/patches/{patch_id}/approve`
- `POST /api/patches/{patch_id}/reject`
- `POST /api/patches/{patch_id}/reconcile`
- `POST /api/workspaces/{workspace_id}/patches/reconcile`
- `GET /api/workspaces/{workspace_id}/index-state`
- `POST /api/workspaces/{workspace_id}/index`
- `POST /api/workspaces/{workspace_id}/semantic/build`

The assistant request logic automatically tries `question`, then `query`, then `prompt` if your Pydantic request model uses a different field name.

## Same-origin setup

Serving the UI from the same FastAPI instance is recommended. It avoids CORS configuration and the UI can leave API Base URL blank.

If the UI and API are on different origins, open **Settings** in the UI and enter the API base URL, for example:

```text
http://10.0.0.4:8085
```

You will also need CORS enabled in FastAPI for that separate frontend origin.

## What works

- Workspace selection
- LLM/API health indicator
- Auto/Fast/Agent chat
- Semantic retrieval toggle
- Safe patch generation
- Patch review drawer
- Syntax-highlight-style diff view
- Validation result display
- Approve / Reject / Reconcile
- Patch history and filters
- Ready patch badge
- Repository HEAD/state hash display
- Dirty working-tree detection
- Structural/semantic freshness
- Refresh structural index
- Refresh semantic index
- User settings saved to localStorage
- Responsive desktop/mobile layout

## Recommended production command

After testing, run Uvicorn behind your existing process manager instead of `--reload`, for example:

```bash
uvicorn app.main:app \
--host 0.0.0.0 \
--port 8085
```

If your existing OutrightBot service already starts FastAPI through PM2/systemd, keep that setup and only restart the service.
